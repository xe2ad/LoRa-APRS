#ifndef APRS_POSITION_H_
#define APRS_POSITION_H_
/*
#include "APRSMessage.h"

class APRSPosition : APRSBody
{
public:
	APRSPosition();
	virtual ~APRSPosition();
	
	double getLatitude() const;
	void setLatitude(const double lat);

	double getLongitude() const;
	void setLongitude(const double longi);

	APRSPositionTypes getPositionType() const;

	virtual bool decode(const String & message);
	virtual String toString() const;

private:
	double _lat;
	double _long;
	APRSPositionTypes _type;
};

class APRSPositionWithTimestamp : APRSPosition
{
public:
	APRSPositionWithTimestamp();
	virtual ~APRSPositionWithTimestamp();

	int getTime() const;
	void setTime(const int time);

	virtual bool decode(const String & message);
	virtual String toString() const;

private:
	int _time;
};
*/
#endif
